package com.review1.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.review1.demo.model.CustomerDetails;
import com.review1.demo.model.Supermarket;
//import com.review.demo.model.Employee;
import com.review1.demo.Service.Review1Service;

@RestController
public class Review1Controller {
	@Autowired
	Review1Service a;
	@GetMapping(value="/getid")
	public List<Supermarket> getAllReview1Model()
	{
		return a.getAllReview1Models();
		
	}
	@PostMapping(value="/postid")
	public Supermarket saveReview1Model(@RequestBody Supermarket b) 
	{
		return a.saveReview1Model(b);
	}
	@PutMapping(value="/putvalue")
	public Supermarket updateReview1Model(@RequestBody Supermarket b)
	{
		
		return a.saveReview1Model(b);
	}
	@DeleteMapping("/deleid/{id}")
	public String deleteReview1Model(@PathVariable("id") int id)
	{
		 return a.deleteReview1Model(id);
	}
	@GetMapping(value="/getid1/{id}")
	public Supermarket getReview1Model(@PathVariable("id") int id)
	{
		return a.getReview1Model(id);
	}
	@GetMapping(value="/sortStudents/{sort}")
	public List<Supermarket> sortdetails(@PathVariable("sort") String id)
	{
		return a.sortdetails(id);
	}
	@GetMapping(value="/page/{offset}/{pagesize}")
	public List<Supermarket> getDetails(@PathVariable int offset,@PathVariable int pagesize)
	{
		return a.getpagingDetails1(offset,pagesize);
	}

	@GetMapping("/pagingdetail/{offset}/{pagesize}/{field}")
	public List<Supermarket>getcustomer(@PathVariable int offset,@PathVariable int pagesize,@PathVariable String field)
	{
		return a.getcustdetails1(offset,pagesize,field);
	}
	@GetMapping("/getprefix")
	public List<Supermarket> fetchEmployeesByNamePrefix(@RequestParam String prefix)
	{
		  return a.fetchEmployeeByNamePrefix(prefix);
	}
	@GetMapping("/getsuffix")
	public List<Supermarket> fetchEmployeeByNameSuffix(@RequestParam String suffix)
	{
		return a.fetchEmployeeByNameSuffix(suffix);
	}
	@GetMapping("/fetchEmp/{dept}/{name}")
	public List<Supermarket> fetchEmployeesByDept(@PathVariable String cost,@PathVariable String name)
	{
		return a.getEmployeesByDept(cost, name);
	}
	@GetMapping("/queryData")
	public List<Supermarket> getDataByQuery(@RequestParam String name,@RequestParam String product_name)
	{
		return a.getDataByQuery(name,product_name);
	}
	@GetMapping("/queryDataName")
	public List<Supermarket> getDataByPName(@RequestParam String name,@RequestParam String product_name)
	{
		return a.getDataByPName(name,product_name);
	}
	@DeleteMapping("/deleteDataQuery")
	public String deleteDataQuery(@RequestParam String name)
	{
		int result = a.deleteDataQuery(name);
		if(result>0)
		{
			return "Record is deleted";
		}
		else 
		{
			return "Problem occured while deleting or no records found";
		}
	}
	@PutMapping("/updateSupermarket")
	public int updateSupermarket(@RequestParam String name,@RequestParam String cost,@RequestParam String id)
	{
		return a.updateSupermarket(name,cost,id);
	}
	@GetMapping("/getDataSupermarket")
	public List<Supermarket> getDataSupermarket(@RequestParam String cost)
	{
		return a.getDataSupermarket(cost);
	}
	@GetMapping("/getDataCustomer")
	public List<CustomerDetails> getDataTournament()
	{
		return a.getDataCustomer();
	}
	@PutMapping("/saveDataCustomer")
	public CustomerDetails saveDataTournament(@RequestBody CustomerDetails data)
	{
		return a.saveDataCustomer(data);
	}

}