package com.review1.demo.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class CustomerDetails {
	@Id
	private int bill_no;
	public int getBill_no() {
		return bill_no;
	}
	public void setBill_no(int bill_no) {
		this.bill_no = bill_no;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public Supermarket getOrder_no() {
		return order_no;
	}
	public void setOrder_no(Supermarket order_no) {
		this.order_no = order_no;
	}
	@Column
	private String cust_name;
	@Column
	private String contact;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn
	private Supermarket order_no;
}